// Application data from the provided JSON
const appData = {
  company: {
    name: "Maruti Suzuki India Limited",
    ticker: "MARUTI.NS",
    sector: "Automobile",
    current_price: 15968,
    price_change: -157,
    price_change_percent: -0.97,
    market_cap: "₹5,02,100 Cr",
    pe_ratio: 34.2,
    roe: 15.9,
    roce: 21.7,
    dividend_yield: 0.85,
    "52_week_high": 16435,
    "52_week_low": 10725
  },
  financial_performance: {
    years: ["FY2021", "FY2022", "FY2023", "FY2024", "FY2025"],
    revenue: [70372, 88330, 118410, 141858, 152913],
    net_profit: [4389, 3880, 8264, 13488, 14500],
    gross_margin: [19.5, 20.2, 20.9, 22.0, 23.6],
    net_margin: [9.5, 11.2, 12.8, 13.5, 14.1],
    roe: [15.2, 17.9, 20.8, 21.8, 22.7],
    roce: [20.3, 22.4, 23.0, 24.2, 25.0]
  },
  quarterly_results: {
    q3_fy25: {
      revenue: 36802,
      net_profit: 3525,
      sales_volume: 566213,
      domestic_sales: 466993,
      exports: 99220,
      growth_revenue: 16,
      growth_profit: 13
    }
  },
  market_share: [
    {company: "Maruti Suzuki", share: 42, position: "Market Leader"},
    {company: "Hyundai", share: 14, position: "Strong No. 2"},
    {company: "Tata Motors", share: 13, position: "Emerging No. 3"},
    {company: "Mahindra", share: 12, position: "SUV Leader"},
    {company: "Toyota", share: 7, position: "Niche Premium"},
    {company: "Kia", share: 6, position: "Growing"},
    {company: "Others", share: 6, position: "Fragmented"}
  ],
  swot: {
    strengths: [
      "Largest passenger vehicle market share (42%)",
      "Extensive dealer and service network (3,000+ outlets)",
      "Strong backing from Suzuki Motor Corporation",
      "Economies of scale leading to operational efficiency",
      "Consistent strong financial performance and dividends"
    ],
    weaknesses: [
      "Over-dependence on small and compact cars",
      "Limited presence in electric vehicle segment",
      "Pricing pressure from growing competition",
      "Increasing costs due to regulatory compliance"
    ],
    opportunities: [
      "Growing Indian automobile market driven by rising income",
      "Expansion in electric and hybrid vehicle offerings",
      "Increasing export potential to emerging markets",
      "Untapped rural and semi-urban markets for growth"
    ],
    threats: [
      "Intense competition from Tata, Hyundai, and new entrants",
      "Changing consumer preferences shifting towards SUVs and EVs",
      "Fluctuating raw material prices impacting costs",
      "Stricter emission and safety regulations increasing costs"
    ]
  },
  esg: {
    scores: [
      {agency: "Sustainalytics", score: "31.4 (High Risk)", rank: "64/84 in Auto"},
      {agency: "Morningstar", score: "Medium Risk", rank: "Typical for Auto"},
      {agency: "NSE Sustainability", score: "68 (Mid-range)", rank: "Mid-range performance"},
      {agency: "Yahoo Finance", score: "25.8 (Medium Risk)", rank: "52nd percentile"}
    ],
    initiatives: [
      "Solar power plants at manufacturing sites",
      "Zero liquid discharge systems",
      "CSR spend of ₹110+ crores annually",
      "Supporting 58 government schools",
      "Training 15,000+ youth annually"
    ]
  },
  recommendation: {
    rating: "BUY",
    target_price: 18500,
    potential_return: 15.9,
    rationale: [
      "Strong market leadership with 42% market share",
      "Consistent financial growth with improving margins",
      "Strategic push into electric vehicles with e-Vitara launch",
      "Near zero debt providing financial flexibility",
      "Historical outperformance vs NIFTY with 108% return over 5 years"
    ],
    risks: [
      "High P/E ratio of 34.2x indicating expensive valuation",
      "Dependence on small car segment",
      "Increasing competition in EV space"
    ]
  },
  key_highlights: [
    "India's largest passenger car maker with 42% market share",
    "Record sales of 22.34 lakh vehicles in FY2025",
    "Highest-ever net profit of ₹14,500 crores",
    "World's 8th most valuable automaker by market cap",
    "First EV e-Vitara launching soon with 500km range"
  ]
};

// Chart.js default colors matching design system
const chartColors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B'];

// DOM Elements
let stockChart, financialChart, marketShareChart;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
  initializeTabs();
  initializeCharts();
  populateData();
});

// Tab functionality
function initializeTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const targetTab = button.getAttribute('data-tab');
      
      // Remove active class from all tabs and contents
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      // Add active class to clicked tab and corresponding content
      button.classList.add('active');
      document.getElementById(targetTab).classList.add('active');
    });
  });
}

// Initialize all charts
function initializeCharts() {
  createStockChart();
  createFinancialChart();
  createMarketShareChart();
}

// Stock Price Chart
function createStockChart() {
  const ctx = document.getElementById('stockChart').getContext('2d');
  
  // Generate mock stock price data for the chart
  const stockPriceData = generateStockPriceData();
  
  stockChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: stockPriceData.labels,
      datasets: [{
        label: 'Stock Price (₹)',
        data: stockPriceData.prices,
        borderColor: chartColors[0],
        backgroundColor: chartColors[0] + '20',
        borderWidth: 3,
        fill: true,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: '52-Week Stock Performance'
        },
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          min: 10000,
          max: 17000
        }
      },
      interaction: {
        intersect: false,
        mode: 'index'
      }
    }
  });
}

// Financial Performance Chart
function createFinancialChart() {
  const ctx = document.getElementById('financialChart').getContext('2d');
  
  financialChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: appData.financial_performance.years,
      datasets: [
        {
          label: 'Revenue (₹ Cr)',
          data: appData.financial_performance.revenue,
          backgroundColor: chartColors[0],
          yAxisID: 'y'
        },
        {
          label: 'Net Profit (₹ Cr)',
          data: appData.financial_performance.net_profit,
          backgroundColor: chartColors[1],
          yAxisID: 'y'
        },
        {
          label: 'ROE (%)',
          data: appData.financial_performance.roe,
          type: 'line',
          borderColor: chartColors[2],
          backgroundColor: chartColors[2],
          yAxisID: 'y1',
          tension: 0.4
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: 'Financial Performance Trends'
        }
      },
      scales: {
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          title: {
            display: true,
            text: 'Amount (₹ Crores)'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {
            display: true,
            text: 'ROE (%)'
          },
          grid: {
            drawOnChartArea: false
          }
        }
      }
    }
  });
}

// Market Share Chart
function createMarketShareChart() {
  const ctx = document.getElementById('marketShareChart').getContext('2d');
  
  marketShareChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: appData.market_share.map(item => item.company),
      datasets: [{
        data: appData.market_share.map(item => item.share),
        backgroundColor: chartColors,
        borderWidth: 2,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: 'Indian Passenger Vehicle Market Share'
        },
        legend: {
          position: 'bottom',
          labels: {
            padding: 20
          }
        }
      }
    }
  });
}

// Generate mock stock price data
function generateStockPriceData() {
  const labels = [];
  const prices = [];
  const currentDate = new Date();
  const currentPrice = appData.company.current_price;
  const highPrice = appData.company["52_week_high"];
  const lowPrice = appData.company["52_week_low"];
  
  // Generate 52 weeks of data
  for (let i = 51; i >= 0; i--) {
    const date = new Date(currentDate);
    date.setDate(date.getDate() - (i * 7));
    labels.push(date.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }));
    
    // Generate price with some randomness but within 52-week range
    const randomFactor = Math.random() * 0.3 + 0.85; // 0.85 to 1.15
    const basePrice = lowPrice + (highPrice - lowPrice) * (Math.sin(i * 0.1) * 0.3 + 0.7);
    prices.push(Math.round(basePrice * randomFactor));
  }
  
  // Ensure last price matches current price
  prices[prices.length - 1] = currentPrice;
  
  return { labels, prices };
}

// Populate all data
function populateData() {
  populateFinancialRatiosTable();
  populateSWOTAnalysis();
  populateESGScores();
}

// Populate Financial Ratios Table
function populateFinancialRatiosTable() {
  const tbody = document.getElementById('ratiosTableBody');
  
  const ratios = [
    {
      metric: 'Gross Margin (%)',
      fy2023: appData.financial_performance.gross_margin[2],
      fy2024: appData.financial_performance.gross_margin[3],
      fy2025: appData.financial_performance.gross_margin[4],
      trend: 'up'
    },
    {
      metric: 'Net Margin (%)',
      fy2023: appData.financial_performance.net_margin[2],
      fy2024: appData.financial_performance.net_margin[3],
      fy2025: appData.financial_performance.net_margin[4],
      trend: 'up'
    },
    {
      metric: 'ROE (%)',
      fy2023: appData.financial_performance.roe[2],
      fy2024: appData.financial_performance.roe[3],
      fy2025: appData.financial_performance.roe[4],
      trend: 'up'
    },
    {
      metric: 'ROCE (%)',
      fy2023: appData.financial_performance.roce[2],
      fy2024: appData.financial_performance.roce[3],
      fy2025: appData.financial_performance.roce[4],
      trend: 'up'
    },
    {
      metric: 'P/E Ratio',
      fy2023: '28.5',
      fy2024: '31.2',
      fy2025: appData.company.pe_ratio,
      trend: 'up'
    }
  ];
  
  tbody.innerHTML = '';
  ratios.forEach(ratio => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${ratio.metric}</td>
      <td>${ratio.fy2023}</td>
      <td>${ratio.fy2024}</td>
      <td>${ratio.fy2025}</td>
      <td class="trend-${ratio.trend}">
        ${ratio.trend === 'up' ? '↗️' : '↘️'}
      </td>
    `;
    tbody.appendChild(row);
  });
}

// Populate SWOT Analysis
function populateSWOTAnalysis() {
  // Strengths
  const strengthsList = document.getElementById('strengthsList');
  strengthsList.innerHTML = '';
  appData.swot.strengths.forEach(strength => {
    const li = document.createElement('li');
    li.textContent = strength;
    strengthsList.appendChild(li);
  });
  
  // Weaknesses
  const weaknessesList = document.getElementById('weaknessesList');
  weaknessesList.innerHTML = '';
  appData.swot.weaknesses.forEach(weakness => {
    const li = document.createElement('li');
    li.textContent = weakness;
    weaknessesList.appendChild(li);
  });
  
  // Opportunities
  const opportunitiesList = document.getElementById('opportunitiesList');
  opportunitiesList.innerHTML = '';
  appData.swot.opportunities.forEach(opportunity => {
    const li = document.createElement('li');
    li.textContent = opportunity;
    opportunitiesList.appendChild(li);
  });
  
  // Threats
  const threatsList = document.getElementById('threatsList');
  threatsList.innerHTML = '';
  appData.swot.threats.forEach(threat => {
    const li = document.createElement('li');
    li.textContent = threat;
    threatsList.appendChild(li);
  });
}

// Populate ESG Scores
function populateESGScores() {
  const scoresList = document.getElementById('esgScoresList');
  scoresList.innerHTML = '';
  
  appData.esg.scores.forEach(scoreData => {
    const scoreDiv = document.createElement('div');
    scoreDiv.className = 'esg-score';
    scoreDiv.innerHTML = `
      <div>
        <div class="score-agency">${scoreData.agency}</div>
        <div class="score-value">${scoreData.rank}</div>
      </div>
      <div class="score-rating">${scoreData.score}</div>
    `;
    scoresList.appendChild(scoreDiv);
  });
}

// Add interactive tooltips and hover effects
function addInteractiveFeatures() {
  // Add hover effects to cards
  const cards = document.querySelectorAll('.card');
  cards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-2px)';
      this.style.boxShadow = 'var(--shadow-lg)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = 'var(--shadow-sm)';
    });
  });
  
  // Add click to expand functionality for SWOT items
  const swotItems = document.querySelectorAll('.swot-list li');
  swotItems.forEach(item => {
    item.addEventListener('click', function() {
      this.classList.toggle('expanded');
    });
  });
}

// Initialize interactive features after DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  setTimeout(addInteractiveFeatures, 100);
});

// Update data periodically (simulate real-time updates)
function simulateRealTimeUpdates() {
  setInterval(() => {
    // Small random price fluctuations
    const priceElement = document.querySelector('.price');
    const changeElement = document.querySelector('.price-change');
    
    if (priceElement && changeElement) {
      const currentPrice = parseInt(priceElement.textContent.replace(/[₹,]/g, ''));
      const fluctuation = (Math.random() - 0.5) * 100; // ±50 rupees
      const newPrice = Math.round(currentPrice + fluctuation);
      const change = newPrice - appData.company.current_price;
      const changePercent = ((change / appData.company.current_price) * 100).toFixed(2);
      
      priceElement.textContent = `₹${newPrice.toLocaleString('en-IN')}`;
      changeElement.textContent = `${change > 0 ? '+' : ''}${change} (${changePercent}%)`;
      changeElement.className = `price-change ${change >= 0 ? 'positive' : 'negative'}`;
    }
  }, 30000); // Update every 30 seconds
}

// Start real-time simulation
setTimeout(simulateRealTimeUpdates, 5000);

// Export functions for potential external use
window.MarutiDashboard = {
  appData,
  initializeTabs,
  initializeCharts,
  populateData
};